import { UserDTO } from './user-dto';

describe('UserDTO', () => {
  it('should create an instance', () => {
    expect(new UserDTO()).toBeTruthy();
  });
});
