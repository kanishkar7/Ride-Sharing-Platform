export class UserDTO {
    // private String userName;
	// private String password;
	// private String role;

    userName!:string;
    password!:string;
    rolecd!:string;
}
