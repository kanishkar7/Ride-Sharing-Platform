package com.cognizant.main.entities;

import java.time.LocalDate;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
@Data
@Entity
@Table(name = " Vechile_Details")
public class VehicleDetails {

	@Id
	@Column(name="Registration_No")
	private String registrationNo;
    
	@Column(name=" RTOName")
	private String RTOName;
	
	@Column(name="Registration_Date")
	private LocalDate RegistrationDate;
	
	@Column(name="Registration_Expires_On")
	private LocalDate RegistrationExpiresOn;
	
	@Column(name="RCDocURL")
	private String RCDocURL;
	
	@Column(name="Insurance_Company_Name")
	private String InsuranceCompanyName;
	
	@Column(name="Insurance_No")
	private int InsuraceNo;
	
	@Column(name="Insuranced_On")
	private LocalDate InsurancedOn;
	
	@Column(name="Insurance_Expires_On")
	private LocalDate InsuranceExpiresOn;
	
	@Column(name="Insurance_CertificateDOCURL")
	private String InsuranceCertificateDOCURL;
	
	@Column(name="PUCCertificate_No")
	private int PUCCertificateNo;
	
	@Column(name="PUCIssued_On")
	private LocalDate PUCIssuedOn;
	
	@Column(name="PUCValid_Until")
	private LocalDate PUCValidUntil;
	
	@Column(name="PUCDOCURL")
	private String PUCDOCURL;
	

	
}
