package com.cognizant.dto;

import lombok.Data;

@Data
public class VehicleTypesDTO {
	
	private int id;	
	private int type;
	private int maxPassengersAllowed;
	private int farePerKM;
	
	
	 
}
