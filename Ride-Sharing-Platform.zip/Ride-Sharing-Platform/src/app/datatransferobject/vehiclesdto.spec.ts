import { Vehiclesdto } from './vehiclesdto';

describe('Vehiclesdto', () => {
  it('should create an instance', () => {
    expect(new Vehiclesdto()).toBeTruthy();
  });
});
