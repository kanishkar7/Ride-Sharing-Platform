insert into vechicle_types values(1,2,2,10);
insert into vechicle_types values(2,4,5,20);


