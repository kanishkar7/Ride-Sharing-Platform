export class Registervehicledto {
    
    registrationNo!:string;
    belongsToUserId!:number;
    vehicleTypeId!:number;
    rtoname!:string;
    inspectionStatus!:string;
    inspectedByUserId!:number;
    inspectedOn!:Date;
    registrationDate!:Date;
    registrationExpiresOn!:Date;
    rcdocurl!:string;
    insuranceCompanyName!:string;
    insuraceNo!:number;
    insurancedOn!:Date;
    insuranceExpiresOn!:Date;
    insuranceCertificateDOCURL!:string;
    puccertificateno!:number;
    pucissuedon!:Date;
    pucvaliduntil!:Date;
    pucdocurl!:string;


}
