import { Vehicletypesdto } from './vehicletypesdto';

describe('Vehicletypesdto', () => {
  it('should create an instance', () => {
    expect(new Vehicletypesdto()).toBeTruthy();
  });
});
