package com.cognizant.main.service;

import java.util.List;


import com.cognizant.dto.RegisterVehicleDTO;
import com.cognizant.dto.VehicleTypesDTO;
import com.cognizant.dto.VehiclesDTO;
import com.cognizant.main.service.VehicleServiceImpl.InvalidRegistrationNoException;

public interface Vehicle {
public abstract List<VehicleTypesDTO> getVehicleTypes();
public abstract VehiclesDTO getVehicleById(int belongsToUserId);


public abstract String deleteVehicles(String registrationNo, int belongsToUserId);
public abstract List<VehiclesDTO> getpending();
public abstract String persistVehicles(RegisterVehicleDTO registerVehicleDTO) throws InvalidRegistrationNoException;
public abstract String updateapprovereject(RegisterVehicleDTO registerVehicleDTO);
VehiclesDTO getpending(int pageNumber);



}
