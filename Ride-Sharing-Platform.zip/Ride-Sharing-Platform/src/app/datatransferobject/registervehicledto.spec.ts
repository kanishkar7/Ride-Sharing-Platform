import { Registervehicledto } from './registervehicledto';

describe('Registervehicledto', () => {
  it('should create an instance', () => {
    expect(new Registervehicledto()).toBeTruthy();
  });
});
