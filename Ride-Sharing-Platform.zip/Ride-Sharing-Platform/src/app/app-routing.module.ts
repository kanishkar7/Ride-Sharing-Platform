import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddNewVehicleComponent } from './add-new-vehicle/add-new-vehicle.component';
import { HttpClientModule } from '@angular/common/http';
import { ViewVehicletypesComponent } from './view-vehicletypes/view-vehicletypes.component';
import { ViewVehiclesbyUseridComponent } from './view-vehiclesby-userid/view-vehiclesby-userid.component';
import { DeleteVehicleComponent } from './delete-vehicle/delete-vehicle.component';
import { ApproveRejectVehicleComponent } from './approve-reject-vehicle/approve-reject-vehicle.component';
import { UpdateInspectionStatusComponent } from './update-inspection-status/update-inspection-status.component';
import { AuthenticateAdminGuardService } from './Service/authenticate-admin-guard.service';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
const routes: Routes = [
  { path : 'home',component : HomeComponent },
  { path : 'home',component : LoginComponent },
  { path : '', component : HomeComponent},
  {path:'AddNewVehicle',component: AddNewVehicleComponent},
  {path:'vehicletypes',component:ViewVehicletypesComponent},
  {path:'viewvehiclesbyuserid',component:ViewVehiclesbyUseridComponent},
  {path:'viewvehiclesbyuserid/DeleteVehicle',component:DeleteVehicleComponent},
  {path:'ApproveRejectVehicle',component:ApproveRejectVehicleComponent},
  {path:'ApproveRejectVehicle/updateInspectionStatus',component:UpdateInspectionStatusComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes), HttpClientModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }
