export class Vehicletypesdto {


    id!:number;
    type!:number;
    maxPassengersAllowed!:number;
    farePerKM!:number;
}
