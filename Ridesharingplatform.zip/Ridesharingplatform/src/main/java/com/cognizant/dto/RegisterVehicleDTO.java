package com.cognizant.dto;

import java.time.LocalDate;
import com.cognizant.utilities.InspectionStatusEnum;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Data;
@Data
public class RegisterVehicleDTO {
	
	private String registrationNo;
	private int belongsToUserId;
	private int vehicleTypeId;
	@Enumerated(EnumType.STRING)
	private InspectionStatusEnum inspectionStatus;
	private int inspectedByUserId;
	private LocalDate inspectedOn;
	private String rtoname;
	private LocalDate registrationDate;
	private LocalDate registrationExpiresOn;
	private String rcdocurl;
	private String insuranceCompanyName;
	private int insuraceNo;
	private LocalDate insurancedOn;
	private LocalDate insuranceExpiresOn;
	private String insuranceCertificateDOCURL;
	private int puccertificateno;
	private LocalDate pucissuedon;
	private LocalDate pucvaliduntil;
	private String pucdocurl;
	private String vehiclesDetailsregistrationNo;
	private String vehiclesregistrationNo;
	
	
	
	
	
}
	