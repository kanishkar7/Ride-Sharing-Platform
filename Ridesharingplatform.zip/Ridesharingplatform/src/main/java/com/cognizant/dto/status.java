package com.cognizant.dto;

import lombok.Data;

@Data
public class status {
 String status;
}
