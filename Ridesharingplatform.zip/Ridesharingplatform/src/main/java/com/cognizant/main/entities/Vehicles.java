package com.cognizant.main.entities;

import java.time.LocalDate;

import com.cognizant.utilities.InspectionStatusEnum;

import jakarta.persistence.*;
import lombok.Data;
@Data
@Entity
@Table(name = "Vechicles")
public class Vehicles {

	@Id
	@Column(name = "Registration_No")
	private String registrationNo;

	@Column(name = "Belongs_To_User_Id")
	private int belongsToUserId;
	
	@ManyToOne
	@JoinColumn(name = "Vechicle_Type_Id", referencedColumnName = "Id")
	private VehicleTypes vehicleTypeId;

	@Enumerated(EnumType.STRING)
	@Column(name = "Inspection_Status")
	private InspectionStatusEnum inspectionStatus;

	@Column(name = "Inspected_By_User_Id")
	private int inspectedByUserId;

	@Column(name = "Inspected_On")
	private LocalDate inspectedOn;
	
	 @OneToOne(cascade = CascadeType.ALL)
	 @PrimaryKeyJoinColumn(name="Registration_No",referencedColumnName="Registration_No")
	private VehicleDetails vehicleDetails; 


   
}
