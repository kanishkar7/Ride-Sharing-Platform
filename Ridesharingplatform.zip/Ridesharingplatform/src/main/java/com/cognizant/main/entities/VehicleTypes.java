package com.cognizant.main.entities;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.Data;
@Data
@Entity(name="Vechicle_Types")
public class VehicleTypes {
	
	@OneToMany(mappedBy="vehicleTypeId",targetEntity=Vehicles.class)
	private List<Vehicles> vechicles;
	@Id
	@Column(name="Id")
    private int id;	
	
	@Column(name="Type")
    private int Type;
	
	@Column(name="Max_Passengers_Allowed")
    private int MaxPassengersAllowed;
	
	@Column(name="Fare_PerKM")
    private int FarePerKM;
	




}
